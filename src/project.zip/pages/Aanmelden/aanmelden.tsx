import { FormContainer } from './components/FormContainer';
import './styles/index.css';

export default function Aanmelden() {
  return <FormContainer />;
}
