import { z } from 'zod';

// Exacte string literals zoals in Supabase
const RolEnum = z.enum(['Deelnemer', 'Begeleider', 'Vrijwilliger'] as const);
const AfstandEnum = z.enum(['2.5 KM', '6 KM', '10 KM', '15 KM'] as const);
const OndersteuningEnum = z.enum(['Ja', 'Nee', 'Anders'] as const);
const StatusEnum = z.enum(['pending', 'approved', 'rejected'] as const);

export const aanmeldSchema = z.object({
  naam: z.string().min(2, 'Naam moet minimaal 2 karakters bevatten'),
  email: z.string().email('Vul een geldig e-mailadres in'),
  telefoon: z.string().optional(),
  rol: RolEnum,
  afstand: AfstandEnum,
  ondersteuning: OndersteuningEnum,
  bijzonderheden: z.string().optional(),
  terms: z.boolean().refine(val => val === true, {
    message: 'Je moet akkoord gaan met de voorwaarden'
  })
});

export type AanmeldFormData = z.infer<typeof aanmeldSchema>;

export interface Inschrijving extends Omit<AanmeldFormData, 'terms'> {
  id?: string;
  created_at?: string;
  status: z.infer<typeof StatusEnum>;
}

// Export de enums voor hergebruik
export type Rol = z.infer<typeof RolEnum>;
export type Afstand = z.infer<typeof AfstandEnum>;
export type Ondersteuning = z.infer<typeof OndersteuningEnum>;
export type Status = z.infer<typeof StatusEnum>; 