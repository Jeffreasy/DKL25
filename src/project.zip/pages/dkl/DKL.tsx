import React from 'react';
import RouteSection from './components/RouteSection';

const DKL: React.FC = () => {
  return (
    <div className="min-h-screen pt-20">
      <RouteSection />
    </div>
  );
};

export default DKL; 