export interface Video {
  id: string;
  videoId: string;
  url: string;
  title: string;
  description: string;
} 