declare module '@mui/icons-material/*' {
  import { SvgIconProps } from '@mui/material'
  const Icon: (props: SvgIconProps) => JSX.Element
  export default Icon
} 