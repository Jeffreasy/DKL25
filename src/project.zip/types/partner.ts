import type { Database } from './supabase'

export type Partner = Database['public']['Tables']['partners']['Row'] 