declare module 'react-use' {
  export function useWindowSize(): {
    width: number;
    height: number;
  };
} 